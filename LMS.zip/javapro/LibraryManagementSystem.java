import java.util.Scanner;

// Class Book
class Book 
{
    private String title;               //instance variables
    private String author;
    private String genre;
    private boolean available;

    public Book(String title, String author, String genre) 
	{
        this.title = title;            //constructor
        this.author = author;
        this.genre = genre;
        this.available = true;
    }

    public String getTitle() {               //getter methods
        return title;
    }

    public String getAuthor() {
        return author;
    }

    public String getGenre() {
        return genre;
    }

    public boolean isAvailable() {
        return available;
    }

    public void updateAvailability(boolean status)           //updateavailability methods
	{            
        this.available = status;
    }

    public void displayBookDetails() {            //display book details
        System.out.println("Title: " + title);
        System.out.println("Author: " + author);
        System.out.println("Genre: " + genre);
        System.out.println("Availability: " + (available ? "Available" : "Not Available"));   //if else condition
    }
}

// Class Member
class Member 
{
    private String name;             //instance variables
    private int id;

    public Member(String name, int id) {        
        this.name = name;                    //constructor
        this.id = id;
    }

    public String getName() {              //getter methods
        return name;
    }

    public int getId() {
        return id;
    }
}

// Class Transaction
class Transaction 
{
    private Book book;
    private Member member;
    private String transactionType;

    public Transaction(Book book, Member member, String transactionType)   //3 parameter of constructor
	{
        this.book = book;
        this.member = member;
        this.transactionType = transactionType;
    }

    public void displayTransactionDetails()  //method to display transaction details
	{
        System.out.println("Transaction Type: " + transactionType);
        System.out.println("Book Details:");
        book.displayBookDetails();      
        System.out.println("Member Details:");
        System.out.println("Name: " + member.getName());
        System.out.println("Member ID: " + member.getId());
        System.out.println("------");
    }
}

// Class Library
class Library 
{
    private static final int INITIAL_MEMBER_ID = 1001;         //constant representing inital member id

    private static final Book[] books =                        //array
	{
            new Book("Harry Potter & the Philosopher's stone","J.K.Rowling", "Fiction"),
            new Book("Peer-e-Kamil", "Umaira Ahmad", "Fiction"),
            new Book("Namal", "Nemrah Ahmed", "Fiction"),
            new Book("The War of Art", "Steve Pressfield", "Non-Fiction"),
            new Book("Girl With a Pearl Earring", "Tracy Chevalier", "Non-Fiction")
    };

    private Member[] members;                               //Member(class) member(variable)
    private Transaction[] transactions;                    //Transaction(class) transaction(variable)
    private int nextMemberId;                             //an int representing next available id

    public Library()                   
	{                                                     // *******Constructor******
        this.members = new Member[10];                   // Initialize with a capacity for 10 members
        this.transactions = new Transaction[100];       // Initialize with a capacity for 100 transactions
        this.nextMemberId = INITIAL_MEMBER_ID;
    }
                                                                      //method
    public void addBook(String title, String author, String genre)    
	{
        Book newBook = new Book(title, author, genre);                   //creates new book object
        // Add the new book to the library's inventory
        System.out.println("Book added successfully!");
    }

    public void registerMember(String name)                             //method to Register a new member
	{
        Member newMember = new Member(name, nextMemberId++);           //creates new member object
        for (int i = 0; i < members.length; i++)                       //iterating through meber arrays
		{
            if (members[i] == null) 
			{
                members[i] = newMember;
                break;
            }
        }
        System.out.println("Member registered successfully! Member ID: " + (nextMemberId - 1));
    }

    public void borrowBook(int memberId, String bookTitle)         //borrow book
	{                                                     //create object
        Member member = findMemberById(memberId);       //finding member to see if he is already registered or not
        if (member != null)                         
		{
            Book book = findBookByTitle(bookTitle);
            if (book != null && book.isAvailable()) 
			{
                // Update book availability
                book.updateAvailability(false);
                // Record the transaction
                for (int i = 0; i < transactions.length; i++) 
				{
                    if (transactions[i] == null) 
					{
                        transactions[i] = new Transaction(book, member, "Borrow");
                        break;
                    }
                }
                System.out.println("Book borrowed successfully!");
            }
			else 
			{
                System.out.println("Book not available for borrowing.");
            }
        } 
		else 
		{
            System.out.println("Member not found.");
        }
    }

    public void returnBook(int memberId, String bookTitle)         //return book
	{
        Member member = findMemberById(memberId);                   //finding member
        if (member != null) 
		{
            Book book = findBookByTitle(bookTitle);                          //finding book
            if (book != null && !book.isAvailable()) 
			{
                // Update book availability
                book.updateAvailability(true);
                // Record the transaction
                for (int i = 0; i < transactions.length; i++)                    //borrow or return?
				{
                    if (transactions[i] == null) 
					{
                        transactions[i] = new Transaction(book, member, "Return");        //transaction record
                        break;
                    }
                }
                System.out.println("Book returned successfully!");
            } 
			else 
			{
                System.out.println("Invalid book or book already returned.");
            }
        } 
		else 
		{
            System.out.println("Member not found.");
        }
    }

    public void displayBookDetails(String bookTitle)                 //book deatail method
	{
        Book book = findBookByTitle(bookTitle);                      //new object
        if (book != null) 
		{
            book.displayBookDetails();
        } 
		else			
		{
            System.out.println("Book not found.");
        }
    }

    public void displayMemberDetails(int memberId)                        //member details
	{
        Member member = findMemberById(memberId);                            //new object
        if (member != null) 
		{
            System.out.println("Member Details:");
            System.out.println("Name: " + member.getName());
            System.out.println("Member ID: " + member.getId());
        } 
		else 
		{
            System.out.println("Member not found.");
        }
    }

    public void displayTransactionHistory()                      //transaction history
	{
        for (Transaction transaction : transactions)    
		{
            if (transaction != null) 
			{
                transaction.displayTransactionDetails();
            }
        }
    }

    private Book findBookByTitle(String title)                     //finding book
	{
        for (Book book : books) 
		{
            if (book.getTitle().equalsIgnoreCase(title)) 
			{
                return book;
            }
        }
        return null;
    }

    private Member findMemberById(int memberId)             //private helping method
	{
        for (Member member : members)                          
		{
            if (member != null && member.getId() == memberId) 
			{
                return member;
            }
        }
        return null;
    }
}

// Class Library Management System
public class LibraryManagementSystem 
{
    public static void main(String[] args) 
	{
        Library library = new Library();
        Scanner scanner = new Scanner(System.in);
        int choice;

        // Adding 5 members
        for (int i = 1; i <= 5; i++) 
		{
            library.registerMember("LMS" + i);
        }

        do {
            displayMenu();
            choice = scanner.nextInt();

            switch (choice) 
			{
                case 1:
                    System.out.println("Enter Book Title:");
                    scanner.nextLine(); // Consume newline
                    String title = scanner.nextLine();
                    System.out.println("Enter Author:");
                    String author = scanner.nextLine();
                    System.out.println("Enter Genre:");
                    String genre = scanner.nextLine();
                    library.addBook(title, author, genre);
                    break;
                case 2:
                    System.out.println("Enter Member Name:");
                    scanner.nextLine(); // Consume newline
                    String memberName = scanner.nextLine();
                    library.registerMember(memberName);
                    break;
                case 3:
                    System.out.println("Enter Member ID:");
                    int memberId = scanner.nextInt();
                    scanner.nextLine(); // Consume newline
                    System.out.println("Enter Book Title:");
                    String borrowBookTitle = scanner.nextLine();
                    library.borrowBook(memberId, borrowBookTitle);
                    break;
                case 4:
                    System.out.println("Enter Member ID:");
                    int returnMemberId = scanner.nextInt();
                    scanner.nextLine(); // Consume newline
                    System.out.println("Enter Book Title:");
                    String returnBookTitle = scanner.nextLine();
                    library.returnBook(returnMemberId, returnBookTitle);
                    break;
                case 5:
                    System.out.println("Enter Book Title:");
                    scanner.nextLine(); // Consume newline
                    String bookTitle = scanner.nextLine();
                    library.displayBookDetails(bookTitle);
                    break;
                case 6:
                    System.out.println("Enter Member ID:");
                    int displayMemberId = scanner.nextInt();
                    library.displayMemberDetails(displayMemberId);
                    break;
                case 7:
                    library.displayTransactionHistory();
                    break;
                case 0:
                    System.out.println("Exiting the Library Management System. Goodbye!");
                    break;
                default:
                    System.out.println("Invalid choice. Please enter a valid option.");
            }

        } 
		while (choice != 0);
    }

    private static void displayMenu() 
	{
        System.out.println("Library Management System Menu:");
        System.out.println("1. Add Book");
        System.out.println("2. Register Member");
        System.out.println("3. Borrow Book");
        System.out.println("4. Return Book");
        System.out.println("5. Display Book Details");
        System.out.println("6. Display Member Details");
        System.out.println("7. Display Transaction History");
        System.out.println("0. Exit");
        System.out.print("Enter your choice: ");
    }
}
